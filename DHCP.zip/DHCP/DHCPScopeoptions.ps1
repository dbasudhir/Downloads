##################################################################
#              Author: Vikas SUkhija
#              Description: Find DHCP SCope Options Values 
#              for particular scope option
#              Date: 12/17/2014
#
#
####################################################################

############Import Module & define variables##################

Import-module .\Microsoft.DHCP.PowerShell.Admin.psm1

$collection =@()
$idval = "6"  ### DNS Scope Option

$days = (get-date).adddays(-60)
$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t

$time = $time.ToString().Replace(":", "-")
               $time = $time.ToString().Replace(" ", "")
$output = ".\" + "DHCPScopeOptions_" + $date + "_" + $time + "_.csv"


##########################################
$srv = Show-DHCPServers
$servers= $srv | select server
$servers | foreach{ 
$server = $_.server
Write-host "Processing Server...............$server" -foregroundcolor Green
$scope=Get-DHCPScope -server  $server
#$scope
$scp = $scope | Select Address
#$scp

	$scp | foreach{ 
	$opt = Get-DHCPScope -server $server -scope $_.Address
        $optscope = $opt | Select -expandproperty options | where{$_.optionId -like $idval} | select Values 

$coll = �� | select ServerName,Scopename,Optionvalues

$coll.ServerName = $server
$coll.Scopename = $_.Address
$coll.Optionvalues = $optscope.values


$collection += $coll


        }

}

$collection | select ServerName,Scopename,@{Name=�Optionvalues�;Expression={$_.Optionvalues}} | export-csv $output -notypeinfo

#######################################################################


