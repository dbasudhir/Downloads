######################################################################
######################################################################
#               Author: Vikas Sukhija
#               Date:- 12/22/2014
#		Modified:- 07/23/2015 (updated to use WINSCP)
#               Description:- This script will upload the file to sftp
#               
######################################################################
######upload file from sftp##########################################

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"

$smtpServer = "smtpserver"
$fromadd = "DoNotReply@labtest.com"
$email1 = "VikasSukhija@labtest.com"

$date1=Get-Date -Hour 0 -Minute 0 -Second 0

Start-Transcript -Path $logs 



$lwrt=Get-ChildItem .\FileV3Upload\FileV3.csv

if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)

$msg.Subject = "Ftp file Monitoring script error"
$msg.Body = $error
$smtp.Send($msg)
exit
       }

if($lwrt.LastWriteTime -ge "$date1")
{
Write-host "File for Today found and will be uploaded to sftp" -ForegroundColor green

.\winscp556\WinSCP.com /script=command1.txt

}
else
{
write-host "Today's date file not found on share" -ForegroundColor yellow
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)

$msg.Subject = "Today's date file not found on share"
$msg.Body = "Today's date file not found on share"
$smtp.Send($msg)

}

########################################################################
if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)

$msg.Subject = "Ftp file Monitoring script error"
$msg.Body = $error
$smtp.Send($msg)
       }

Stop-Transcript


#############################################################################